# tlvl-javascript-20s
Страница курса по Javascript (TLVL весна 2020)

1. Переменные и типы в Javascript - 5 февраля
2. Средства версионирования кода - 12 февраля
3. Функции в Javascript - 19 февраля
4. Условные и логические операторы в Javascript - 4 марта  
  https://developer.mozilla.org/en-US/docs/Web/HTML/Element/table  
  https://css-tricks.com/complete-guide-table-element/  
5. Массивы и циклы - 11 марта  
  https://glitch.com/edit/#!/tlvl-accounting  
  https://null@api.glitch.com/git/tlvl-accounting  

## Необходимые ссылки
https://atom.io - основной редактор курса  
https://teletype.atom.io/ - плагин для совместной работы над кодом

## Используемые учебники
https://eloquentjavascript.net  
https://learn.javascript.ru  

## Ссылка на свежий Teletype
https://github.com/dfisun/tlvl-javascript-20s/wiki/Atom-Teletype
