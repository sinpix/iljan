
console.log('currentExpenses', currentExpenses);
console.log('add Milk (1.00)',
            addExpense('Milk', 1.00));
console.log('add Playstation 4 (399)',
            addExpense('Playstation 4', 399));
console.log('add Videogame (69.99)',
            addExpense('Videogame', 69.99));
console.log('try to hack (-45.26)',
            addExpense('Hacker', -45.26));
console.log('currentExpenses', currentExpenses);
